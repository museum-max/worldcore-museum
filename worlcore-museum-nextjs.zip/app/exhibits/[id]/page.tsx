import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { artifacts } from "@/lib/artifacts";

type Props = { params: { id: string } };

export function generateStaticParams() {
  return artifacts.map((artifact) => ({ id: artifact.id }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const artifact = artifacts.find((item) => item.id === params.id);
  return { title: artifact ? `${artifact.name} | WORLCORE MUSEUM` : "Exhibit | WORLCORE MUSEUM" };
}

export default function ArtifactDetailPage({ params }: Props) {
  const artifact = artifacts.find((item) => item.id === params.id);
  if (!artifact) notFound();
  return <main className="mx-auto min-h-[70vh] max-w-6xl px-5 py-14 lg:px-8 lg:py-20">
    <Link href="/gallery" className="text-xs uppercase tracking-[.15em] text-gold">← Back to collection</Link>
    <div className="mt-8 grid gap-10 md:grid-cols-2 md:items-start">
      <div className="relative aspect-[4/5] overflow-hidden border border-gold/20 bg-panel"><Image src={artifact.image} alt={artifact.name} fill sizes="(max-width: 768px) 100vw, 50vw" className="object-cover" unoptimized/></div>
      <div className="pt-2"><p className="eyebrow">{artifact.category} · {artifact.era}</p><h1 className="mt-4 font-display text-4xl leading-tight sm:text-5xl">{artifact.name}</h1><p className="mt-6 text-base leading-8 text-muted">{artifact.description}</p><div className="gold-line my-8"/><dl className="space-y-5 text-sm"><div><dt className="text-xs uppercase tracking-widest text-muted">Collection / location</dt><dd className="mt-1">{artifact.location}</dd></div><div><dt className="text-xs uppercase tracking-widest text-muted">Record status</dt><dd className="mt-1">Demonstration content — verification required</dd></div></dl><Link href="/exhibits" className="gold-button mt-8">Visit 3D exhibition ↗</Link><p className="mt-6 text-xs leading-6 text-muted">This starter uses illustrative sample content and externally hosted image URLs. Confirm historical accuracy and image licensing before using this as an official catalog.</p></div>
    </div>
  </main>;
}
