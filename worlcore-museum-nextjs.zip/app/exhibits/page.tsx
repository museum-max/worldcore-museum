import type { Metadata } from "next";
import Exhibit3D from "@/components/Exhibit3D";

export const metadata: Metadata = { title: "3D Exhibits | WORLCORE MUSEUM" };

export default function ExhibitsPage() {
  return <main className="mx-auto min-h-[70vh] max-w-7xl px-5 py-16 lg:px-8 lg:py-24">
    <p className="eyebrow">Digital exhibition hall</p><h1 className="mt-4 font-display text-5xl sm:text-6xl">Artifacts in <span className="italic text-gold">motion.</span></h1>
    <p className="mt-5 max-w-2xl text-sm leading-7 text-muted">Interact with this illustrative 3D relic. Drag to rotate and use the scroll wheel or pinch gesture to zoom.</p>
    <div className="mt-10 grid items-start gap-8 lg:grid-cols-[1.35fr_.65fr]"><Exhibit3D/><aside className="panel-border p-6 sm:p-8"><p className="eyebrow">Digital object · 001</p><h2 className="mt-4 font-display text-3xl">The Gilded Relic</h2><p className="mt-4 text-sm leading-7 text-muted">A fictional demonstration model designed to show how a digital exhibit can be explored in three dimensions. It is not a scan of an authenticated historical object.</p><div className="gold-line my-6"/><dl className="space-y-4 text-sm"><div className="flex justify-between gap-4"><dt className="text-muted">Object type</dt><dd>Demonstration model</dd></div><div className="flex justify-between gap-4"><dt className="text-muted">Material</dt><dd className="text-right">Digital gold shader</dd></div><div className="flex justify-between gap-4"><dt className="text-muted">Controls</dt><dd>Rotate / Zoom</dd></div></dl></aside></div>
  </main>;
}
