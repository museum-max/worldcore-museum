import type { Metadata } from "next";
import { BookOpen, Globe2, Landmark } from "lucide-react";

export const metadata: Metadata = { title: "About | WORLCORE MUSEUM" };

export default function AboutPage() {
  return <main className="mx-auto min-h-[70vh] max-w-5xl px-5 py-16 lg:px-8 lg:py-24">
    <p className="eyebrow">Our story</p><h1 className="mt-4 max-w-4xl font-display text-5xl leading-tight sm:text-6xl">Preserving yesterday. <span className="italic text-gold">Inspiring tomorrow.</span></h1>
    <p className="mt-8 max-w-3xl text-lg leading-8 text-[#b9b0a0]">WORLCORE MUSEUM is a digital museum concept created to make history and material culture more accessible. We bring together stories about artifacts, creative traditions, and the civilizations that shaped the world.</p>
    <div className="gold-line my-12"/>
    <div className="grid gap-8 md:grid-cols-3">
      <article className="panel-border p-6"><Landmark className="text-gold" size={28}/><h2 className="mt-5 font-display text-2xl">Preserve</h2><p className="mt-3 text-sm leading-7 text-muted">Treat historical objects and their context with care, accuracy, and respect.</p></article>
      <article className="panel-border p-6"><BookOpen className="text-gold" size={28}/><h2 className="mt-5 font-display text-2xl">Educate</h2><p className="mt-3 text-sm leading-7 text-muted">Make complex histories easier to explore through clear, accessible storytelling.</p></article>
      <article className="panel-border p-6"><Globe2 className="text-gold" size={28}/><h2 className="mt-5 font-display text-2xl">Connect</h2><p className="mt-3 text-sm leading-7 text-muted">Explore the links between cultures, eras, and the experiences we share.</p></article>
    </div>
    <p className="mt-10 border-l-2 border-gold pl-5 text-sm leading-7 text-muted">Editorial note: the sample artifacts and descriptions in this starter are illustrative, not authenticated catalog records. Verify provenance, dates, image rights, and historical claims before publishing them as factual collection data.</p>
  </main>;
}
