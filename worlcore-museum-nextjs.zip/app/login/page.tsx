import type { Metadata } from "next";
import AuthForm from "@/components/AuthForm";

export const metadata: Metadata = { title: "Sign in | WORLCORE MUSEUM" };

export default function LoginPage() {
  return <main className="mx-auto flex min-h-[70vh] max-w-xl flex-col justify-center px-5 py-16"><p className="eyebrow text-center">Member access</p><h1 className="mt-4 text-center font-display text-4xl">Welcome <span className="italic text-gold">back.</span></h1><p className="mb-8 mt-3 text-center text-sm text-muted">Sign in to your WORLCORE MUSEUM account.</p><AuthForm mode="login"/></main>;
}
