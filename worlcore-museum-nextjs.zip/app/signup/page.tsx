import type { Metadata } from "next";
import AuthForm from "@/components/AuthForm";

export const metadata: Metadata = { title: "Create account | WORLCORE MUSEUM" };

export default function SignupPage() {
  return <main className="mx-auto flex min-h-[70vh] max-w-xl flex-col justify-center px-5 py-16"><p className="eyebrow text-center">Become a member</p><h1 className="mt-4 text-center font-display text-4xl">Join the <span className="italic text-gold">journey.</span></h1><p className="mb-8 mt-3 text-center text-sm text-muted">Create an account to access member features.</p><AuthForm mode="signup"/></main>;
}
