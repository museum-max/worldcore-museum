import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function AdminPage() {
  const supabase = createClient();
  if (!supabase) return <main className="mx-auto max-w-4xl px-5 py-20"><p className="eyebrow">Administration</p><h1 className="mt-4 font-display text-4xl">Admin dashboard</h1><p className="mt-4 leading-7 text-muted">Connect Supabase and run the SQL setup in supabase/schema.sql. Admin access is denied until your user is explicitly assigned the admin role.</p><Link href="/login" className="gold-button mt-6">Sign in</Link></main>;
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).maybeSingle();
  if (profile?.role !== "admin") {
    return <main className="mx-auto min-h-[70vh] max-w-3xl px-5 py-20"><p className="eyebrow">Restricted area</p><h1 className="mt-4 font-display text-4xl">Admin access required.</h1><p className="mt-4 leading-7 text-muted">Your account is signed in, but it has not been granted the admin role. Ask the project owner to assign your role securely in Supabase.</p><Link href="/account" className="outline-button mt-6">Return to account</Link></main>;
  }
  return <main className="mx-auto min-h-[70vh] max-w-7xl px-5 py-16 lg:px-8 lg:py-20"><p className="eyebrow">WORLCORE control room</p><h1 className="mt-4 font-display text-5xl">Admin <span className="italic text-gold">dashboard.</span></h1><p className="mt-4 text-muted">Authenticated administrator: {user.email}</p><div className="mt-10 grid gap-4 md:grid-cols-3"><div className="panel-border p-6"><p className="text-xs uppercase tracking-widest text-muted">Catalog starter</p><p className="mt-3 font-display text-2xl">6 sample exhibits</p><p className="mt-2 text-sm text-muted">Demo content currently lives in lib/artifacts.ts.</p></div><div className="panel-border p-6"><p className="text-xs uppercase tracking-widest text-muted">Access control</p><p className="mt-3 font-display text-2xl">Role protected</p><p className="mt-2 text-sm text-muted">Admin role checked against Supabase profiles.</p></div><div className="panel-border p-6"><p className="text-xs uppercase tracking-widest text-muted">Next step</p><p className="mt-3 font-display text-2xl">Manage collection</p><p className="mt-2 text-sm text-muted">Connect catalog CRUD actions and upload storage before launch.</p></div></div><div className="mt-8 border border-gold/20 p-6"><h2 className="font-display text-2xl">Admin notes</h2><p className="mt-3 text-sm leading-7 text-muted">This first version secures the dashboard route but does not yet include artifact create/edit/delete forms. Use Supabase Row Level Security for every future data operation; never expose a service-role key in frontend code.</p></div></main>;
}
