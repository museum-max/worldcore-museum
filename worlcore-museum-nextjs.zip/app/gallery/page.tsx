import type { Metadata } from "next";
import GalleryExplorer from "@/components/GalleryExplorer";

export const metadata: Metadata = { title: "Collection | WORLCORE MUSEUM" };

export default function GalleryPage() {
  return <main className="mx-auto min-h-[70vh] max-w-7xl px-5 py-16 lg:px-8 lg:py-24">
    <p className="eyebrow">Explore the archive</p><h1 className="mt-4 font-display text-5xl sm:text-6xl">The <span className="italic text-gold">Collection.</span></h1>
    <p className="mt-5 max-w-2xl text-sm leading-7 text-muted">Search the sample catalog by artifact name, era, location, or category. Collection entries are demo content and should be replaced with verified object records.</p>
    <div className="gold-line my-10"/>
    <GalleryExplorer/>
  </main>;
}
