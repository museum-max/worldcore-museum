import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function AccountPage() {
  const supabase = createClient();
  if (!supabase) return <main className="mx-auto max-w-3xl px-5 py-20"><h1 className="font-display text-4xl">Account setup required</h1><p className="mt-4 text-muted">Configure Supabase environment variables to enable member accounts.</p></main>;
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  return <main className="mx-auto min-h-[70vh] max-w-4xl px-5 py-20"><p className="eyebrow">Member space</p><h1 className="mt-4 font-display text-4xl">Welcome to WORLCORE.</h1><p className="mt-4 text-muted">Signed in as {user.email}</p><form action="/auth/signout" method="post" className="mt-8"><button className="outline-button">Sign out</button></form><Link href="/gallery" className="gold-button mt-5">Explore collection</Link></main>;
}
