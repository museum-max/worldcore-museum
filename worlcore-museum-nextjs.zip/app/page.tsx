import Link from "next/link";
import Image from "next/image";
import { ArrowDown, ArrowRight, Globe2, Landmark, Sparkles } from "lucide-react";
import ArtifactCard from "@/components/ArtifactCard";
import { artifacts } from "@/lib/artifacts";

export default function HomePage() {
  return <main>
    <section className="hero-grid relative overflow-hidden border-b border-gold/15">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_70%_35%,_rgba(145,103,29,.2),_transparent_55%)]"/>
      <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-5 py-20 md:grid-cols-[1.03fr_.97fr] md:py-28 lg:px-8 lg:py-32">
        <div>
          <p className="eyebrow flex items-center gap-3"><span className="h-px w-10 bg-gold"/> A journey through human history</p>
          <h1 className="mt-7 max-w-2xl font-display text-5xl leading-[1.05] sm:text-6xl lg:text-7xl">Every artifact <span className="italic text-gold">holds</span> a world of stories.</h1>
          <p className="mt-7 max-w-xl text-base leading-8 text-[#aaa397]">Discover the objects, cultures, and remarkable ideas that shaped civilizations. Step into a museum where history feels close enough to touch.</p>
          <div className="mt-9 flex flex-wrap gap-3"><Link href="/gallery" className="gold-button">Explore the collection <ArrowRight size={16}/></Link><Link href="/about" className="outline-button">Our story</Link></div>
          <div className="mt-14 grid max-w-lg grid-cols-3 border-t border-gold/20 pt-6">
            <div><p className="font-display text-2xl text-gold">01</p><p className="mt-1 text-[10px] uppercase tracking-[.14em] text-muted">Human origins</p></div>
            <div><p className="font-display text-2xl text-gold">02</p><p className="mt-1 text-[10px] uppercase tracking-[.14em] text-muted">World cultures</p></div>
            <div><p className="font-display text-2xl text-gold">03</p><p className="mt-1 text-[10px] uppercase tracking-[.14em] text-muted">Living legacy</p></div>
          </div>
        </div>
        <div className="relative mx-auto w-full max-w-xl">
          <div className="absolute -inset-4 border border-gold/20"/>
          <div className="relative aspect-[4/5] overflow-hidden bg-[#19150e]">
            <Image src="https://images.unsplash.com/photo-1564399579883-451a5d44ec08?auto=format&fit=crop&w=1200&q=90" alt="Artifact display with warm museum lighting" fill priority sizes="(max-width: 768px) 100vw, 50vw" className="object-cover opacity-85" unoptimized/>
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/5 to-black/10"/>
            <div className="absolute bottom-7 left-7 right-7">
              <p className="eyebrow">Featured collection · No. 001</p>
              <h2 className="mt-3 font-display text-3xl">Echoes of the Ancient World</h2>
              <p className="mt-2 max-w-sm text-sm leading-6 text-[#c9c0ae]">Objects that carry the memory of generations.</p>
            </div>
          </div>
          <div className="absolute -bottom-6 -left-6 hidden h-20 w-20 items-center justify-center border border-gold/50 bg-[#080808] text-gold md:flex"><Landmark size={34}/></div>
        </div>
      </div>
      <div className="flex items-center justify-center gap-3 border-t border-gold/10 py-4 text-[10px] uppercase tracking-[.25em] text-muted"><ArrowDown size={13} className="text-gold"/> Scroll to explore</div>
    </section>

    <section id="gallery" className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-28">
      <div className="mb-10 flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
        <div><p className="eyebrow">The collection</p><h2 className="mt-4 font-display text-4xl sm:text-5xl">Treasures of <span className="italic text-gold">time.</span></h2><p className="mt-4 max-w-xl text-sm leading-7 text-muted">Explore a selection of exhibits inspired by the artistry, innovation, and imagination of past civilizations.</p></div>
        <Link href="/gallery" className="inline-flex items-center gap-2 text-xs uppercase tracking-[.15em] text-gold hover:text-cream">View all artifacts <ArrowRight size={15}/></Link>
      </div>
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{artifacts.filter((a) => a.featured).map((artifact) => <ArtifactCard key={artifact.id} artifact={artifact}/>)}</div>
    </section>

    <section className="border-y border-gold/15 bg-[#0d0c0a]">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-16 md:grid-cols-3 lg:px-8 lg:py-20">
        <div className="md:col-span-1"><p className="eyebrow">More than a museum</p><h2 className="mt-4 font-display text-3xl leading-tight">History deserves to be <span className="italic text-gold">experienced.</span></h2></div>
        <div className="grid gap-8 sm:grid-cols-2 md:col-span-2">
          <div><Globe2 className="text-gold" size={25}/><h3 className="mt-4 font-display text-xl">A world of cultures</h3><p className="mt-3 text-sm leading-7 text-muted">Follow connections across eras and regions, discovering the shared stories behind our differences.</p></div>
          <div><Sparkles className="text-gold" size={25}/><h3 className="mt-4 font-display text-xl">Explore in 3D</h3><p className="mt-3 text-sm leading-7 text-muted">Rotate and inspect a digital artifact in an interactive exhibit made for curious minds.</p><Link href="/exhibits" className="mt-4 inline-block text-xs uppercase tracking-widest text-gold">Enter 3D hall ↗</Link></div>
        </div>
      </div>
    </section>
    <section className="mx-auto max-w-7xl px-5 py-20 text-center lg:px-8 lg:py-24"><p className="eyebrow">Your journey starts here</p><h2 className="mx-auto mt-4 max-w-3xl font-display text-4xl sm:text-5xl">Step closer to the past. <span className="italic text-gold">See the world anew.</span></h2><Link href="/gallery" className="gold-button mt-8">Begin exploring <ArrowRight size={16}/></Link></section>
  </main>;
}
