export type Artifact = {
  id: string;
  name: string;
  era: string;
  category: string;
  location: string;
  image: string;
  description: string;
  featured?: boolean;
};

export const artifacts: Artifact[] = [
  {
    id: "golden-mask",
    name: "Ceremonial Golden Mask",
    era: "Ancient World",
    category: "Artifacts",
    location: "Royal Collection",
    image: "https://images.unsplash.com/photo-1577083552431-6e5fd01aa342?auto=format&fit=crop&w=1000&q=85",
    description: "A ceremonial object inspired by the artistry and symbolism of ancient royal traditions.",
    featured: true
  },
  {
    id: "classical-bust",
    name: "Marble Philosopher",
    era: "Classical Era",
    category: "Sculpture",
    location: "Mediterranean Gallery",
    image: "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?auto=format&fit=crop&w=1000&q=85",
    description: "A sculptural study celebrating the enduring influence of classical art and philosophy.",
    featured: true
  },
  {
    id: "ancient-vessel",
    name: "Decorated Ancient Vessel",
    era: "Bronze Age",
    category: "Pottery",
    location: "Origins Gallery",
    image: "https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=1000&q=85",
    description: "A vessel-inspired exhibit exploring how everyday objects can reveal ancient lives.",
    featured: true
  },
  {
    id: "stone-guardian",
    name: "Stone Guardian",
    era: "Ancient Kingdoms",
    category: "Sculpture",
    location: "World Civilizations",
    image: "https://images.unsplash.com/photo-1603565816030-6b389eeb23cb?auto=format&fit=crop&w=1000&q=85",
    description: "A monumental form inspired by guardian figures that stood watch over sacred places.",
    featured: false
  },
  {
    id: "archive-book",
    name: "The Archivist's Volume",
    era: "Medieval Era",
    category: "Manuscripts",
    location: "Knowledge Hall",
    image: "https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=1000&q=85",
    description: "A tribute to the manuscripts, records, and libraries that preserved human knowledge.",
    featured: false
  },
  {
    id: "bronze-relic",
    name: "Bronze Age Relic",
    era: "Bronze Age",
    category: "Artifacts",
    location: "Origins Gallery",
    image: "https://images.unsplash.com/photo-1564399579883-451a5d44ec08?auto=format&fit=crop&w=1000&q=85",
    description: "An exhibit celebrating the craft traditions and material innovation of early societies.",
    featured: false
  }
];

export const categories = ["All", ...Array.from(new Set(artifacts.map((item) => item.category)))];
