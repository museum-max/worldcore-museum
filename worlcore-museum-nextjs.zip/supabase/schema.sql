-- WORLCORE MUSEUM starter schema
-- Run in Supabase Dashboard > SQL Editor.
-- Do not put your service_role key in client-side code.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'member' check (role in ('member', 'admin')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

create policy "Users can read their own profile"
on public.profiles for select
to authenticated
using (auth.uid() = id);

-- Profiles are created from auth signup. Role always defaults to member.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, email, role)
  values (new.id, new.email, 'member')
  on conflict (id) do update set email = excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Only trusted project owners should assign an admin role from the Supabase SQL editor.
-- After creating your account, find its UUID in Authentication > Users, then run:
-- update public.profiles set role = 'admin' where id = 'YOUR-USER-UUID';

create table if not exists public.artifacts (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  era text,
  category text not null default 'Artifacts',
  location text,
  image_url text,
  description text not null default '',
  published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.artifacts enable row level security;

create policy "Anyone can read published artifacts"
on public.artifacts for select
to anon, authenticated
using (published = true);

create policy "Admins can manage artifacts"
on public.artifacts for all
to authenticated
using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
)
with check (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
);
