# WORLCORE MUSEUM

A responsive black-and-gold museum website starter built with Next.js App Router, TypeScript, Tailwind CSS, Supabase Auth, and React Three Fiber.

## Included

- Luxury dark homepage and responsive navigation
- Gallery search and category filters
- Sample artifact detail pages
- About page and interactive 3D demonstration exhibit
- Supabase email/password sign up and sign in
- Protected member page and role-checked admin route
- SQL schema with Row Level Security policies

## Requirements

- Node.js 20 LTS recommended
- npm
- A GitHub account and Vercel account
- Supabase project for real authentication and role-based admin access

## Run locally

1. Install Node.js 20 LTS.
2. In this folder, run `npm install`.
3. Copy `.env.example` to `.env.local`.
4. Add your Supabase Project URL and anon/publishable key from Supabase Project Settings > API.
5. In Supabase SQL Editor, run `supabase/schema.sql`.
6. In Supabase Authentication settings, configure your Site URL and Redirect URLs. For local development add `http://localhost:3000/auth/callback`. After deployment add `https://YOUR-DOMAIN/auth/callback`.
7. Run `npm run dev` and open `http://localhost:3000`.

Without Supabase environment variables, the public pages still run, but authentication and the live role check are not enabled.

## Give your account admin access

1. Sign up using the website.
2. In Supabase Dashboard > Authentication > Users, copy the UUID for your account.
3. In SQL Editor, run `update public.profiles set role = 'admin' where id = 'YOUR-USER-UUID';` replacing the placeholder with the exact UUID.
4. Sign out and sign in again, then visit `/admin`.

Never assign roles from a public form. Never expose a Supabase service-role key in `NEXT_PUBLIC_*` variables or browser code.

## Deploy to GitHub and Vercel

1. Create a new empty GitHub repository.
2. Upload/push the contents of this folder to the repository root. `package.json` must be at the root, not inside an extra nested project folder.
3. In Vercel, choose **Add New > Project**, import the repository, and keep the detected Next.js settings.
4. In Vercel Project Settings > Environment Variables, add:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
5. Add variables for Production, Preview, and Development as needed. Redeploy after changing them.
6. In Supabase Auth URL Configuration, set the production Site URL to your Vercel domain and add `https://YOUR-VERCEL-DOMAIN/auth/callback` to Redirect URLs.
7. Deploy. Check the deployment logs if the build fails.

## Before production

- Replace the illustrative sample artifact records in `lib/artifacts.ts` with verified collection data.
- Verify image licenses and attribution. Current image URLs are external demo images.
- Add real object photography and provenance/history references.
- Add admin create/edit/delete forms and connect the UI to the `artifacts` table. The starter protects the dashboard route but does not yet implement catalog CRUD.
- Review Supabase RLS policies and account/email confirmation settings.
- Add privacy policy, terms, accessibility review, error monitoring, backups, and rate limiting as appropriate.
- Run `npm run build` before pushing changes.

## Troubleshooting

- **Auth says Supabase is not configured:** check `.env.local` and restart `npm run dev`.
- **Email confirmation link fails:** check Supabase Redirect URLs and include `/auth/callback`.
- **Admin access denied:** verify your user has a matching `profiles` row with role `admin`.
- **Images do not load:** the sample uses remote images; confirm network access and replace URLs with licensed assets as desired.
- **3D canvas is blank:** update your browser/GPU drivers and check the browser console for WebGL errors.
