"use client";

import { Canvas } from "@react-three/fiber";
import { OrbitControls, Stage } from "@react-three/drei";
import { Suspense } from "react";

function Relic() {
  return <group rotation={[0, -0.25, 0]}>
    <mesh castShadow position={[0, 0.35, 0]}>
      <dodecahedronGeometry args={[1, 1]} />
      <meshStandardMaterial color="#c99c43" metalness={0.82} roughness={0.24} />
    </mesh>
    <mesh position={[0, -0.75, 0]} rotation={[Math.PI / 2, 0, 0]}>
      <cylinderGeometry args={[0.85, 0.95, 0.2, 48]} />
      <meshStandardMaterial color="#4b3514" metalness={0.72} roughness={0.32} />
    </mesh>
    <mesh position={[0, -0.92, 0]} rotation={[Math.PI / 2, 0, 0]}>
      <cylinderGeometry args={[1.05, 1.05, 0.12, 48]} />
      <meshStandardMaterial color="#d6ad57" metalness={0.7} roughness={0.25} />
    </mesh>
  </group>;
}

export default function Exhibit3D() {
  return <div className="h-[360px] w-full overflow-hidden border border-gold/20 bg-[radial-gradient(ellipse_at_center,_#302410_0%,_#100e0a_55%,_#080808_100%)] sm:h-[460px]" aria-label="Interactive 3D artifact model. Drag to rotate and scroll to zoom.">
    <Canvas camera={{ position: [0, 0, 4.2], fov: 45 }} dpr={[1, 1.75]}>
      <Suspense fallback={null}>
        <Stage environment="city" intensity={0.65} adjustCamera={false}><Relic /></Stage>
        <OrbitControls enablePan={false} minDistance={2.5} maxDistance={7} />
      </Suspense>
    </Canvas>
    <p className="pointer-events-none -mt-8 relative z-10 px-4 text-center text-[10px] uppercase tracking-[.2em] text-gold/80">Drag to rotate · Scroll to zoom</p>
  </div>;
}
