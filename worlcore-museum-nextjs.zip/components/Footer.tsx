import Link from "next/link";

export default function Footer() {
  return <footer className="border-t border-gold/15 bg-[#060606]">
    <div className="mx-auto flex max-w-7xl flex-col gap-6 px-5 py-10 md:flex-row md:items-end md:justify-between lg:px-8">
      <div><p className="font-display text-xl tracking-[.16em]">WORLCORE <span className="gold-text">MUSEUM</span></p><p className="mt-2 max-w-md text-sm leading-6 text-muted">Preserving the stories of humanity, one artifact at a time.</p></div>
      <div className="flex flex-wrap gap-5 text-sm text-muted"><Link href="/about" className="hover:text-gold">About</Link><Link href="/gallery" className="hover:text-gold">Collection</Link><Link href="/login" className="hover:text-gold">Member access</Link><Link href="/admin" className="hover:text-gold">Admin</Link></div>
      <p className="text-xs text-muted">© {new Date().getFullYear()} WORLCORE MUSEUM</p>
    </div>
  </footer>;
}
