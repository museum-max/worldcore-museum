 "use client";

import { useMemo, useState } from "react";
import { Search, SlidersHorizontal } from "lucide-react";
import ArtifactCard from "@/components/ArtifactCard";
import { artifacts, categories } from "@/lib/artifacts";

export default function GalleryExplorer() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const filtered = useMemo(() => artifacts.filter((item) => {
    const matchesCategory = category === "All" || item.category === category;
    const text = `${item.name} ${item.era} ${item.category} ${item.location}`.toLowerCase();
    return matchesCategory && text.includes(query.toLowerCase().trim());
  }), [query, category]);

  return <div>
    <div className="mb-8 grid gap-4 md:grid-cols-[1fr_auto]">
      <label className="flex items-center gap-3 border border-gold/20 bg-[#100f0d] px-4 py-3">
        <Search size={18} className="text-gold"/>
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search artifacts, eras, or places..." className="w-full bg-transparent text-sm outline-none placeholder:text-[#746e62]" />
      </label>
      <div className="flex items-center gap-2 text-xs text-muted"><SlidersHorizontal size={16} className="text-gold"/> Filter by category</div>
    </div>
    <div className="mb-8 flex flex-wrap gap-2">
      {categories.map((item) => <button key={item} onClick={() => setCategory(item)} className={`border px-4 py-2 text-xs uppercase tracking-[.12em] transition ${category === item ? "border-gold bg-gold text-black" : "border-gold/20 text-muted hover:border-gold hover:text-gold"}`}>{item}</button>)}
    </div>
    {filtered.length ? <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{filtered.map((artifact) => <ArtifactCard key={artifact.id} artifact={artifact}/>)}</div> : <div className="border border-gold/20 py-16 text-center"><p className="font-display text-2xl">No artifacts found</p><p className="mt-2 text-sm text-muted">Try another keyword or category.</p></div>}
    <p className="mt-6 text-xs text-muted">Showing {filtered.length} of {artifacts.length} sample exhibits. Replace sample records with verified collection data before public launch.</p>
  </div>;
}
