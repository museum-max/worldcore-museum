import Link from "next/link";
import { Compass, Menu, UserRound } from "lucide-react";

export default function Navbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-[#d6ad57]/15 bg-[#080808]/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
        <Link href="/" className="flex items-center gap-3" aria-label="WORLCORE MUSEUM home">
          <span className="grid h-10 w-10 place-items-center border border-gold text-gold"><Compass size={23}/></span>
          <span><span className="block font-display text-lg tracking-[.14em]">WORLCORE</span><span className="block text-[9px] tracking-[.42em] text-gold">M U S E U M</span></span>
        </Link>
        <nav className="hidden items-center gap-8 text-xs uppercase tracking-[.16em] text-[#c8c0b0] md:flex">
          <Link className="hover:text-gold" href="/#gallery">Collection</Link>
          <Link className="hover:text-gold" href="/about">Our Story</Link>
          <Link className="hover:text-gold" href="/exhibits">3D Exhibits</Link>
        </nav>
        <div className="flex items-center gap-3">
          <Link href="/login" className="outline-button !px-3 !py-2"><UserRound size={15}/><span className="hidden sm:inline">Sign in</span></Link>
          <Link href="/gallery" className="gold-button hidden sm:inline-flex">Explore Collection</Link>
          <Link href="/gallery" aria-label="Open collection" className="p-2 text-gold sm:hidden"><Menu size={21}/></Link>
        </div>
      </div>
    </header>
  );
}
