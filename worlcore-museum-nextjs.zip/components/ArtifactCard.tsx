import Image from "next/image";
import Link from "next/link";
import type { Artifact } from "@/lib/artifacts";

export default function ArtifactCard({ artifact }: { artifact: Artifact }) {
  return <Link href={`/exhibits/${artifact.id}`} className="artifact-card group block overflow-hidden border border-gold/15 bg-[#100f0d]">
    <div className="relative aspect-[4/5] overflow-hidden bg-[#171512]">
      <Image src={artifact.image} alt={artifact.name} fill sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw" className="artifact-image object-cover" unoptimized />
      <span className="absolute left-4 top-4 border border-gold/40 bg-black/75 px-3 py-1 text-[10px] uppercase tracking-[.18em] text-gold">{artifact.category}</span>
    </div>
    <div className="p-5">
      <p className="text-[10px] uppercase tracking-[.2em] text-muted">{artifact.era} · {artifact.location}</p>
      <h3 className="mt-3 font-display text-xl group-hover:text-gold">{artifact.name}</h3>
      <p className="mt-3 line-clamp-2 text-sm leading-6 text-muted">{artifact.description}</p>
      <span className="mt-5 inline-block text-xs uppercase tracking-[.16em] text-gold">Discover artifact ↗</span>
    </div>
  </Link>;
}
