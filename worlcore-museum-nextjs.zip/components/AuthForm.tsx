"use client";

import { FormEvent, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

export default function AuthForm({ mode }: { mode: "login" | "signup" }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const isSignup = mode === "signup";

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage("");
    const supabase = createClient();
    if (!supabase) {
      setMessage("Supabase is not configured yet. Add the environment variables from .env.example.");
      return;
    }
    setBusy(true);
    const result = isSignup
      ? await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${window.location.origin}/auth/callback` } })
      : await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (result.error) { setMessage(result.error.message); return; }
    if (isSignup && !result.data.session) {
      setMessage("Account created. Check your email to confirm your account, then sign in.");
      return;
    }
    router.push("/account");
    router.refresh();
  }

  return <form onSubmit={submit} className="panel-border space-y-5 bg-[#0e0d0b] p-6 sm:p-8">
    <div><label htmlFor="email" className="mb-2 block text-xs uppercase tracking-widest text-muted">Email address</label><input id="email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full border border-gold/20 bg-black px-4 py-3 text-sm outline-none focus:border-gold"/></div>
    <div><label htmlFor="password" className="mb-2 block text-xs uppercase tracking-widest text-muted">Password</label><input id="password" type="password" required minLength={8} autoComplete={isSignup ? "new-password" : "current-password"} value={password} onChange={(e) => setPassword(e.target.value)} className="w-full border border-gold/20 bg-black px-4 py-3 text-sm outline-none focus:border-gold"/><p className="mt-2 text-[11px] text-muted">Use at least 8 characters.</p></div>
    {message && <p role="status" className="border border-gold/20 p-3 text-sm leading-6 text-gold">{message}</p>}
    <button disabled={busy} className="gold-button w-full disabled:cursor-not-allowed disabled:opacity-60">{busy ? "Please wait..." : isSignup ? "Create account" : "Sign in"}</button>
    <p className="text-center text-sm text-muted">{isSignup ? "Already registered?" : "New to WORLCORE?"} <Link className="text-gold hover:underline" href={isSignup ? "/login" : "/signup"}>{isSignup ? "Sign in" : "Create an account"}</Link></p>
  </form>;
}
